<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package startup
 */

get_header();
?>
	<div class="container-fluid bg-primary py-5 bg-header" style="margin-bottom: 90px;">
            <div class="row py-5">
                <div class="col-12 pt-lg-5 mt-lg-5 text-center">
                    <h1 class="display-4 text-white animated zoomIn"><?php the_title(); ?></h1>
                    <a href="<?php echo home_url('/'); ?>" class="h5 text-white">Home</a>
                    <i class="far fa-circle text-white px-2"></i>
                    <a href="" class="h5 text-white"><?php the_title(); ?></a>
                </div>
            </div>
        </div>

	<main id="primary" class="site-main">

	<div class="container-fluid py-5 wow fadeInUp" data-wow-delay="0.1s">
        <div class="container py-5">
            <div class="row g-5">
                <div class="col-lg-8">
                    <!-- Blog Detail Start -->
                    <div class="mb-5">
                        <img class="img-fluid w-100 rounded mb-5" src="<?php the_post_thumbnail_url(); ?>" alt="">
                        <h1 class="mb-4"><?php the_title();?></h1>
                        <?php the_content(); ?>
                    </div>		
			<?php


			// If comments are open or we have at least one comment, load up the comment template.
			if ( comments_open() || get_comments_number() ) :
				comments_template();
			endif;?>
				</div>

		
		<?php
		get_sidebar();
		?>
		
		</div>
		</div>
		</div>

	</main><!-- #main -->

<?php

get_footer();
