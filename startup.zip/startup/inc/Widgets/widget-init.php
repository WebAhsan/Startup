<?php

/**
 * Register Search Widget
 */
if (file_exists(get_template_directory()) . "/inc/Widgets/search-widget.php") {
    require get_template_directory() . "/inc/Widgets/search-widget.php";
}
/**
 * Register Category Widget
 */
if (
    file_exists(get_template_directory()) . "/inc/Widgets/category-widget.php"
) {
    require get_template_directory() . "/inc/Widgets/category-widget.php";
}
/**
 * Register Recent Post Widget
 */
if (file_exists(get_template_directory()) . "/inc/Widgets/recent-post.php") {
    require get_template_directory() . "/inc/Widgets/recent-post.php";
}
/**
 * Register Tags Widget
 */
if (file_exists(get_template_directory()) . "/inc/Widgets/tag-widget.php") {
    require get_template_directory() . "/inc/Widgets/tag-widget.php";
}
/**
 * Register Plain Widget
 */
if (file_exists(get_template_directory()) . "/inc/Widgets/plain-widget.php") {
    require get_template_directory() . "/inc/Widgets/plain-widget.php";
}

/**
 * Register About Widget
 */
if (file_exists(get_template_directory()) . "/inc/Widgets/about-widget.php") {
    require get_template_directory() . "/inc/Widgets/about-widget.php";
}

/**
 * Register Tags Widget
 */
if (file_exists(get_template_directory()) . "/inc/Widgets/get-touch-widget.php") {
    require get_template_directory() . "/inc/Widgets/get-touch-widget.php";
}

