<?php
/**
 * @package startup
 */
 
if ( ! function_exists('startup_option') ) {
	function startup_option($id, $fallback = false, $param = false ) {
		global $startup_options;
		if ( $fallback == false ) $fallback = '';
		$output = ( isset($startup_options[$id]) && $startup_options[$id] !== '' ) ? $startup_options[$id] : $fallback;
		if ( !empty($startup_options[$id]) && $param ) {
			$output = $startup_options[$id][$param];
		}
		return $output;
	}
}
