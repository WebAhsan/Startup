<?php
/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package startup
 */

?>

		<div class="col-md-6 wow slideInUp" data-wow-delay="0.1s">
			<div class="blog-item bg-light rounded overflow-hidden">
		<div class="blog-img position-relative overflow-hidden">
			<img class="img-fluid" src="<?php the_post_thumbnail_url(); ?>" alt="">
			<span class="position-absolute top-0 start-0 bg-primary text-white rounded-end mt-5 py-2 px-4 cat-des"><a href="<?php the_permalink(); ?>"><?php the_category(' '); ?></a></span>
		</div>
		<div class="p-4">
			<div class="d-flex mb-3">
				<small class="me-3"><i class="far fa-user text-primary me-2"></i><?php the_author(); ?></small>
				<small><i class="far fa-calendar-alt text-primary me-2"></i><?php echo get_the_date('j F, Y') ?></small>
			</div>
			<h4 class="mb-3"><?php the_title(); ?></h4>
			<p><?php echo get_the_excerpt();?></p>
			<a class="text-uppercase" href="<?php the_permalink(); ?>">Read More <i class="bi bi-arrow-right"></i></a>
		</div>
		</div>
		
	</div>

