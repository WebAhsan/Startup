<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package startup
 */

get_header(); ?>

<div class="container-fluid bg-primary py-5 bg-header" style="margin-bottom: 90px;">
            <div class="row py-5">
                <div class="col-12 pt-lg-5 mt-lg-5 text-center">
                <?php if (have_posts()):
                   if (is_home() && !is_front_page()): ?>
                    <h1 class="display-4 text-white animated zoomIn"><?php if (is_page('blog')) {echo 'Blog Grid';}
			   else {echo 'Blog Grid';}?></h1>
                    <?php endif; ?>
                    <a href="<?php echo home_url('/'); ?>" class="h5 text-white">Home</a>
                    <i class="far fa-circle text-white px-2"></i>
                    <a href="" class="h5 text-white"><?php if (is_page('blog')) {echo 'Blog Grid';}
			   else {echo 'Blog Grid';}?></a>
                </div>
            </div>
        </div>
	<main id="primary" class="site-main">



            <div class="container-fluid py-5 wow fadeInUp" data-wow-delay="0.1s">
                <div class="container py-5">
                    <div class="row g-5">
                        <!-- Blog list Start -->
                        <div class="col-lg-8">
                            <div class="row g-5">
            <?php /* Start the Loop */
            while (have_posts()):
                the_post();

                /*
                 * Include the Post-Type-specific template for the content.
                 * If you want to override this in a child theme, then include a file
                 * called content-___.php (where ___ is the Post Type name) and that will be used instead.
                 */
                get_template_part("template-parts/content", get_post_type());
            endwhile; ?>
                  <nav aria-label="Page navigation">
                        <ul class="pagination pagination-lg m-0">
                    <?php the_posts_pagination([
                        "mid_size" => 2,
                        "prev_text" => __(
                            '&nbsp;&nbsp;&nbsp;
                            <span aria-hidden="true"><i class="bi bi-arrow-right"></i></span>',
                            "startup"
                        ),
                        "next_text" => __(
                            '&nbsp;&nbsp;&nbsp;
                            <span aria-hidden="true"><i class="bi bi-arrow-right"></i></span>
                          ',
                            "startup"
                        ),
                    ]); ?>
                      </ul>
                    </nav>
                <?php
  else:
      get_template_part("template-parts/content", "none");
  endif; ?>
                       </div>
                  </div>
                  <?php get_sidebar(); ?>
               </div>
            </div>
          </div>

	</main><!-- #main -->

        <!-- Vendor Start -->
        <div class="container-fluid py-5 wow fadeInUp" data-wow-delay="0.1s">
        <div class="container py-5 mb-5">
            <h2>Hello</h2>
            <div class="bg-white">
                <div class="owl-carousel vendor-carousel">
                    <img src="<?php echo get_template_directory_uri();?>/assets/img/vendor-1.jpg" alt="">
                    <img src="<?php echo get_template_directory_uri();?>/assets/img/vendor-2.jpg" alt="">
                    <img src="<?php echo get_template_directory_uri();?>/assets/img/vendor-3.jpg" alt="">
                    <img src="<?php echo get_template_directory_uri();?>/assets/img/vendor-4.jpg" alt="">
                    <img src="<?php echo get_template_directory_uri();?>/assets/img/vendor-5.jpg" alt="">
                    <img src="<?php echo get_template_directory_uri();?>/assets/img/vendor-6.jpg" alt="">
                    <img src="<?php echo get_template_directory_uri();?>/assets/img/vendor-7.jpg" alt="">
                    <img src="<?php echo get_template_directory_uri();?>/assets/img/vendor-8.jpg" alt="">
                    <img src="<?php echo get_template_directory_uri();?>/assets/img/vendor-9.jpg" alt="">
                </div>
            </div>

        </div>
    </div>
    <!-- Vendor End -->



<?php get_footer();
?>
